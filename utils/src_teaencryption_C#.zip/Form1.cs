using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TeaCrypto
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox txtData;
		private System.Windows.Forms.TextBox txtKey;
		private string cipher;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.txtData = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtKey = new System.Windows.Forms.TextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(152, 156);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(128, 32);
			this.button1.TabIndex = 0;
			this.button1.Text = "Encrypt String Data";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtData
			// 
			this.txtData.Location = new System.Drawing.Point(8, 56);
			this.txtData.MaxLength = 512;
			this.txtData.Multiline = true;
			this.txtData.Name = "txtData";
			this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtData.Size = new System.Drawing.Size(272, 88);
			this.txtData.TabIndex = 7;
			this.txtData.Text = "This is a test string to encrypt.";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Data to Encrypt:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(32, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Key:";
			// 
			// txtKey
			// 
			this.txtKey.Location = new System.Drawing.Point(36, 8);
			this.txtKey.Name = "txtKey";
			this.txtKey.Size = new System.Drawing.Size(244, 20);
			this.txtKey.TabIndex = 6;
			this.txtKey.Text = "0123456789";
			// 
			// button2
			// 
			this.button2.Enabled = false;
			this.button2.Location = new System.Drawing.Point(8, 156);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(124, 32);
			this.button2.TabIndex = 5;
			this.button2.Text = "Decrypt String Data";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(286, 200);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.txtKey);
			this.Controls.Add(this.txtData);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Tea Encryption";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			XTea t = new XTea();			
			cipher = t.EncryptString(txtData.Text, txtKey.Text);
			txtData.Text = cipher;
			txtData.ReadOnly = true;
			button2.Enabled = true;
			button1.Enabled = false;
			txtData.Focus();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			XTea t = new XTea();		
			// The textbox control cannot display all encrypted value characters.
			// So use the cipher variable to obtain the cipher text instead of the textbox.
			txtData.Text = t.Decrypt(cipher, txtKey.Text);
			txtData.ReadOnly = false;
			button2.Enabled = false;
			button1.Enabled = true;
			txtData.Focus();
		}
	}
}
